//
//  main.m
//  Blend Capture
//
//  Created by Gi Hyun Lee on 9/17/12.
//  Copyright (c) 2012 Manning Publications Co. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "BCAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([BCAppDelegate class]));
    }
}
