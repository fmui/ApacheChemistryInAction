//
//  BCAppDelegate.h
//  Blend Capture
//
//  Created by Gi Hyun Lee on 9/17/12.
//  Copyright (c) 2012 Manning Publications Co. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BCViewController;

@interface BCAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) BCViewController *viewController;

@end
