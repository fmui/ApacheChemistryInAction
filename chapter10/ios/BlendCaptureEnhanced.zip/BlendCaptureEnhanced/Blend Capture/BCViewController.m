//
//  BCViewController.m
//  Blend Capture
//
//  Created by Gi Hyun Lee on 9/17/12.
//  Copyright (c) 2012 Manning Publications Co. All rights reserved.
//

#import "BCViewController.h"
#import "CMISSession.h"

@interface BCViewController ()
@property (nonatomic, strong, retain) AVAudioRecorder *audioRecorder;
@property (nonatomic, strong, retain) AVAudioPlayer *audioPlayer;
@property (nonatomic, strong, retain) NSString *capturedAudioFilePath;
@property (nonatomic, strong, retain) CMISSession *cmisSession;
@property (nonatomic, strong, retain) NSString *uploadFolderId;

- (void)button:(UIButton *)button enabled:(BOOL)enable;
@end

@implementation BCViewController
@synthesize audioRecorder = _audioRecorder;
@synthesize audioPlayer = _audioPlayer;
@synthesize capturedAudioFilePath = _capturedAudioFilePath;
@synthesize messageLabel = _messageLabel;
@synthesize recordButton = _recordButton;
@synthesize playButton = _playButton;
@synthesize stopButton = _stopButton;
@synthesize uploadButton = _uploadButton;
@synthesize cmisSession = _cmisSession;
@synthesize uploadFolderId = _uploadFolderId;


#pragma view lifecycle methods

- (void)viewDidUnload
{
    [super viewDidUnload];

    self.audioRecorder = nil;
    self.audioPlayer = nil;
    self.messageLabel = nil;
    self.recordButton = nil;
    self.playButton = nil;
    self.stopButton = nil;
    self.uploadButton = nil;
}

- (void)viewDidLoad
{
    [super viewDidLoad];


    // Create the session parameters object
    CMISSessionParameters *sessionParams = [[CMISSessionParameters alloc] initWithBindingType:CMISBindingTypeAtomPub];
    sessionParams.atomPubUrl = [NSURL URLWithString:@"http://localhost:8081/inmemory/atom"];
    sessionParams.repositoryId = @"A1";
    sessionParams.username = @"admin";
    sessionParams.password = @"admin";

    // Initializing and Authenticating the CMISSession
    [CMISSession connectWithSessionParameters:sessionParams completionBlock:
     ^(CMISSession *session, NSError *error)
     {
         if (nil == session)
         {
             // Handle Error
             if (error) {
                 NSLog(@"Failed to connect session - %@", error.localizedDescription);
             }
         }
         else
         {
             self.cmisSession = session;
             // Authentication Success! Lets now retrieve the cmis:objectId for the Folder
             // at path /blend/Unsorted.  This is the folder in which we will upload to.
             [self.cmisSession retrieveObjectByPath:@"/blend/Unsorted" completionBlock:
              ^(CMISObject *object, NSError *error)
              {
                  if (nil == object)
                  {
                      if (error) {
                          NSLog(@"Failed to retrieve Folder Object at path /blend/Unsorted: %@", error.localizedDescription);
                      }
                  }
                  else
                  {
                      // Successfully retrieved the folder for path /blend/Unsorted
                      // Storing the cmis:objectId
                      self.uploadFolderId = object.identifier;
                  }
              }];
         }
     }];

    [self button:self.stopButton enabled:NO];
    [self button:self.playButton enabled:NO];
    [self button:self.recordButton enabled:YES];
    [self button:self.uploadButton enabled:NO];

    self.messageLabel.text = @"Press Record to start";

    NSArray *dirPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [dirPaths objectAtIndex:0];
    self.capturedAudioFilePath = [documentsDirectory stringByAppendingPathComponent:@"capturedAudio.aac"];

    NSURL *capturedAudioFileUrl = [NSURL fileURLWithPath:self.capturedAudioFilePath];

    NSDictionary *recordSettings = [NSDictionary dictionaryWithObjectsAndKeys:
                                    [NSNumber numberWithFloat: 44100.0], AVSampleRateKey,
                                    [NSNumber numberWithInt: kAudioFormatMPEG4AAC], AVFormatIDKey,
                                    [NSNumber numberWithInt: 1], AVNumberOfChannelsKey,
                                    [NSNumber numberWithInt: AVAudioQualityMax],
                                    AVEncoderAudioQualityKey,
                                    nil];

    NSError *error = nil;
    self.audioRecorder = [[AVAudioRecorder alloc] initWithURL:capturedAudioFileUrl settings:recordSettings error:&error];

    if (error)
    {
        NSLog(@"Error while initializing the audio recorder: %@", [error localizedDescription]);
    }
    else
    {
        [self.audioRecorder prepareToRecord];
    }
}

- (void)button:(UIButton *)button enabled:(BOOL)enable
{
    button.enabled = enable;
}

#pragma mark -
#pragma mark IBAction methods

- (void)recordButtonPressed
{
    if (!self.audioRecorder.recording)
    {
        [self button:self.stopButton enabled:YES];
        [self button:self.playButton enabled:NO];
        [self button:self.recordButton enabled:NO];
        [self button:self.uploadButton enabled:NO];

        self.messageLabel.text = @"Audio is being captured! Press Stop to stop recording.";

        [self.audioRecorder record];
    }
}

- (void)stopButtonPressed
{
    [self button:self.stopButton enabled:NO];
    [self button:self.playButton enabled:YES];
    [self button:self.recordButton enabled:YES];
    [self button:self.uploadButton enabled:YES];

    self.uploadButton.hidden = NO;

    if (self.audioRecorder.recording)
    {
        [self.audioRecorder stop];
        self.messageLabel.text = @"Audio recording stopped!";
    }
    else if (self.audioPlayer.playing)
    {
        [self.audioPlayer stop];
        self.messageLabel.text = @"Audio playback stopped!";
    }
}

- (void)playButtonPressed
{
    if (!self.audioRecorder.recording)
    {
        [self button:self.stopButton enabled:YES];
        [self button:self.playButton enabled:YES];
        [self button:self.recordButton enabled:NO];
        [self button:self.uploadButton enabled:NO];

        self.messageLabel.text = @"Audio is being played back!  Press Stop to stop playing.";

        NSError *error;
        self.audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:self.audioRecorder.url error:&error];
        self.audioPlayer.delegate = self;
        if (error)
        {
            NSLog(@"Error while initializing the audio player: %@", [error localizedDescription]);
        }
        else
        {
            [self.audioPlayer play];
        }
    }
}

- (void)uploadButtonPressed
{
    // Helper block to enable all buttons
    void (^reenableButtonsBlock)() = ^()
    {
        [self button:self.stopButton enabled:NO];
        [self button:self.playButton enabled:YES];
        [self button:self.recordButton enabled:YES];
        [self button:self.uploadButton enabled:YES];
    };
    // Upload Completion Block
    void (^completionBlock)(NSString *objectId, NSError *error) =
    ^(NSString *objectId, NSError *error)
    {
        if (nil == objectId)
        {
            self.messageLabel.text = @"Upload Failed";
        }
        else
        {
            self.messageLabel.text = @"Upload Success";
        }

        reenableButtonsBlock();
    };

    // Disable and hide all buttons while upload is in progress
    [self button:self.stopButton enabled:NO];
    [self button:self.playButton enabled:NO];
    [self button:self.recordButton enabled:NO];
    [self button:self.uploadButton enabled:NO];

    // Update the message to inform the user that an upload is in progress.
    self.messageLabel.text = @"Upload in Progress...";

    // Generate the cmis:name for the uploaded audio file
    NSString *documentName = [NSString stringWithFormat:@"audio-captured-%f.aac",
                              [[NSDate date] timeIntervalSince1970]];

    // Set the name and objectType for the document being created
    NSMutableDictionary *documentProperties = [NSMutableDictionary dictionary];
    [documentProperties setObject:documentName forKey:@"cmis:name"];
    [documentProperties setObject:@"cmis:document" forKey:@"cmis:objectTypeId"];

    // create the document
    [self.cmisSession createDocumentFromFilePath:self.capturedAudioFilePath
                                        mimeType:@"audio/aac"
                                      properties:documentProperties
                                        inFolder:self.uploadFolderId
                                 completionBlock:completionBlock
                                   progressBlock:NULL];
}



#pragma mark -
#pragma mark AVAudioRecorderDelegate Delegate Methods

- (void)audioRecorderDidFinishRecording:(AVAudioRecorder *)recorder successfully:(BOOL)flag
{
    self.messageLabel.text = @"Audio capture finished!";
}

- (void)audioRecorderEncodeErrorDidOccur:(AVAudioRecorder *)recorder error:(NSError *)error
{
    NSLog(@"Encode Error occurred");
}


#pragma mark -
#pragma mark AVAudioPlayerDelegate Delegate Methods

- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag
{
    [self button:self.stopButton enabled:NO];
    [self button:self.playButton enabled:YES];
    [self button:self.recordButton enabled:YES];
    [self button:self.uploadButton enabled:YES];

    self.messageLabel.text = @"Audio finished playing!";
}

- (void)audioPlayerDecodeErrorDidOccur:(AVAudioPlayer *)player error:(NSError *)error
{
    NSLog(@"Decode Error occurred");
}


@end
