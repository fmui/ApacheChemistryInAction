//
//  BCViewController.m
//  Blend Capture
//
//  Created by Gi Hyun Lee on 9/17/12.
//  Copyright (c) 2012 Manning Publications Co. All rights reserved.
//

#import "BCViewController.h"

@interface BCViewController ()
@property (nonatomic, strong, retain) AVAudioRecorder *audioRecorder;
@property (nonatomic, strong, retain) AVAudioPlayer *audioPlayer;
@property (nonatomic, strong, retain) NSString *capturedAudioFilePath;

- (void)button:(UIButton *)button enabled:(BOOL)enable;
@end

@implementation BCViewController
@synthesize audioRecorder = _audioRecorder;
@synthesize audioPlayer = _audioPlayer;
@synthesize capturedAudioFilePath = _capturedAudioFilePath;
@synthesize messageLabel = _messageLabel;
@synthesize recordButton = _recordButton;
@synthesize playButton = _playButton;
@synthesize stopButton = _stopButton;


#pragma view lifecycle methods

- (void)viewDidUnload
{
    [super viewDidUnload];

    self.audioRecorder = nil;
    self.audioPlayer = nil;
    self.messageLabel = nil;
    self.recordButton = nil;
    self.playButton = nil;
    self.stopButton = nil;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    [self button:self.stopButton enabled:NO];
    [self button:self.playButton enabled:NO];
    [self button:self.recordButton enabled:YES];

    self.messageLabel.text = @"Press Record to start";

    NSArray *dirPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [dirPaths objectAtIndex:0];
    self.capturedAudioFilePath = [documentsDirectory stringByAppendingPathComponent:@"capturedAudio.aac"];

    NSURL *capturedAudioFileUrl = [NSURL fileURLWithPath:self.capturedAudioFilePath];

    NSDictionary *recordSettings = [NSDictionary dictionaryWithObjectsAndKeys:
                                    [NSNumber numberWithFloat: 44100.0], AVSampleRateKey,
                                    [NSNumber numberWithInt: kAudioFormatMPEG4AAC], AVFormatIDKey,
                                    [NSNumber numberWithInt: 1], AVNumberOfChannelsKey,
                                    [NSNumber numberWithInt: AVAudioQualityMax],
                                    AVEncoderAudioQualityKey,
                                    nil];

    NSError *error = nil;
    self.audioRecorder = [[AVAudioRecorder alloc] initWithURL:capturedAudioFileUrl settings:recordSettings error:&error];
    
    if (error)
    {
        NSLog(@"Error while initializing the audio recorder: %@", [error localizedDescription]);
    }
    else
    {
        [self.audioRecorder prepareToRecord];
    }
}

- (void)button:(UIButton *)button enabled:(BOOL)enable
{
    button.enabled = enable;
}

#pragma mark -
#pragma mark IBAction methods

- (void)recordButtonPressed
{
    if (!self.audioRecorder.recording)
    {
        [self button:self.stopButton enabled:YES];
        [self button:self.playButton enabled:NO];
        [self button:self.recordButton enabled:NO];
        self.messageLabel.text = @"Audio is being captured! Press Stop to stop recording.";
        
        [self.audioRecorder record];
    }
}

- (void)stopButtonPressed
{
    [self button:self.stopButton enabled:NO];
    [self button:self.playButton enabled:YES];
    [self button:self.recordButton enabled:YES];

    if (self.audioRecorder.recording)
    {
        [self.audioRecorder stop];
        self.messageLabel.text = @"Audio recording stopped!";
    }
    else if (self.audioPlayer.playing)
    {
        [self.audioPlayer stop];
        self.messageLabel.text = @"Audio playback stopped!";
    }
}

- (void)playButtonPressed
{
    if (!self.audioRecorder.recording)
    {
        [self button:self.stopButton enabled:YES];
        [self button:self.playButton enabled:YES];
        [self button:self.recordButton enabled:NO];
        
        self.messageLabel.text = @"Audio is being played back!  Press Stop to stop playing.";

        NSError *error;
        self.audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:self.audioRecorder.url error:&error];
        self.audioPlayer.delegate = self;
        if (error)
        {
            NSLog(@"Error while initializing the audio player: %@", [error localizedDescription]);
        }
        else
        {
            [self.audioPlayer play];
        }
    }
}

#pragma mark -
#pragma mark AVAudioRecorderDelegate Delegate Methods

- (void)audioRecorderDidFinishRecording:(AVAudioRecorder *)recorder successfully:(BOOL)flag
{
    self.messageLabel.text = @"Audio capture finished!";
}

- (void)audioRecorderEncodeErrorDidOccur:(AVAudioRecorder *)recorder error:(NSError *)error
{
    NSLog(@"Encode Error occurred");
}


#pragma mark -
#pragma mark AVAudioPlayerDelegate Delegate Methods

- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag
{
    [self button:self.stopButton enabled:NO];
    [self button:self.playButton enabled:YES];
    [self button:self.recordButton enabled:YES];
    
    self.messageLabel.text = @"Audio finished playing!";
}
- (void)audioPlayerDecodeErrorDidOccur:(AVAudioPlayer *)player error:(NSError *)error
{
    NSLog(@"Decode Error occurred");
}


@end
