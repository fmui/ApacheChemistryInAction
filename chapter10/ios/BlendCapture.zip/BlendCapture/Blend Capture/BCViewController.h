//
//  BCViewController.h
//  Blend Capture
//
//  Created by Gi Hyun Lee on 9/17/12.
//  Copyright (c) 2012 Manning Publications Co. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface BCViewController : UIViewController  <AVAudioRecorderDelegate, AVAudioPlayerDelegate>

@property (nonatomic, strong, retain) IBOutlet UILabel *messageLabel;
@property (nonatomic, strong, retain) IBOutlet UIButton *playButton;
@property (nonatomic, strong, retain) IBOutlet UIButton *recordButton;
@property (nonatomic, strong, retain) IBOutlet UIButton *stopButton;

- (IBAction)playButtonPressed;
- (IBAction)recordButtonPressed;
- (IBAction)stopButtonPressed;

@end
