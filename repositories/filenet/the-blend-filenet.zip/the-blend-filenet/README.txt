
Extract the-blend-with-FileNet.zip into C:\
	Note:  Extract preserving paths.  C:\the-blend-filenet must exist after the extraction.

	
Add The Blend's metadata to a FileNet object store
--------------------------------------------------
This section describes how to import classes, properties, and property templates into an object store.

Open FileNet Enterprise Manager.
Connect to the domain which has the object store that will be used for The Blend.
Select an object store.
Right-click > All tasks > Import All
Import Manifest File=C:\the-blend-filenet\the-blend-filenet_CEExport_Manifest.xml
Accept the defaults for the remaining fields.
Click Import.
You should see "Successfully imported ...." for each property template and class.
Wait for Import to complete.  
	It can take several minutes.
	The last line of the dialog should say "Import Successful!".
	Exit the Import Status dialog, then exit the Import Helper dialog.
Verfy that classes were created.
	Expand Document Class under the object store.  Verify the following class hierarchy:
		Note
		Office Document
		PDF Document
		Taggable
			Image
			Media
				Audio File
				Video File
				Album
		Text Document
			Lyrics
			Poem
	
	
CMIS for FileNet
----------------
This section assumes you have an object store with The Blend's metadata.	
	
Configure CMIS for FileNet for the object store that has The Blend's metadata.
Start CMIS for FileNet.
(Optional) With CMIS Workbench or other CMIS client, verify
	cmis:document has the subtypes created above.
If any question, compare type defs to the book's InMemory Server.	


Configure The Blend for FileNet
-------------------------------
This section assumes you have The Blend in an Eclipse JEE workspace.

Copy the four files in C:\the-blend-filenet\src\main\resources to 
	the the-blend Eclipse project's src\main\resources\ folder.
Edit /the-blend/src/main/java/com/manning/cmis/theblend/session/OpenCMISSessionFactory.java:
	Modify the parameter Map to reference your CMIS for Filenet.
Edit /the-blend/src/main/java/com/manning/cmis/theblend/session/IdMapping.java:
	Replace four constants with:
	private static final String TYPES_PROPERTIES_FILE = "type-ids.properties.p8";
	private static final String PROPERTIES_PROPERTIES_FILE = "property-ids.properties.p8";
	private static final String TYPES_QUERY_NAMES_FILE = "type-query-names.properties.p8";
	private static final String PROPERTIES_QUERY_NAMES_FILE = "property-query-names.properties.p8";

	
	

Please post any questions or comments to the book forum at:
  http://www.manning-sandbox.com/forum.jspa?forumID=833
	

	
